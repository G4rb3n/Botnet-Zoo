#!/bin/sh

TEST_SSH_SSH=../ssh
TEST_SSH_SSHD=../sshd
TEST_SSH_SSHAGENT=../ssh-agent
TEST_SSH_SSHADD=../ssh-add
TEST_SSH_SSHKEYGEN=../ssh-keygen
TEST_SSH_SSHKEYSCAN=../ssh-keyscan
TEST_SSH_SFTP=../sftp
TEST_SSH_SFTPSERVER=../sftp-server

pmake

